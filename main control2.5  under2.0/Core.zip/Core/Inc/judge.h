//#ifndef _UNDER_CONTROL_H
//#define _UNDER_CONTROL_H

//#include "stdint.h"

//uint8_t direction_judge(void);
//void getAD(void);

//#endif
