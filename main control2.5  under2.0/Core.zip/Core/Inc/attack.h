#ifndef _UNDER_CONTROL_H
#define _UNDER_CONTROL_H


void attack(void);

#endif
