#ifndef _UNDER_CONTROL_H
#define _UNDER_CONTROL_H

#include "stdint.h"

uint8_t corner_get(void);
void under_stage_control(void);

#endif
