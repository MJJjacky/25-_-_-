#ifndef __CONTROL_H
#define __CONTROL_H

#include "stdint.h"
#include "serial.h"
#include "usart.h"

uint8_t edge_scan(void);
void tai_shang_control(void);

#endif
